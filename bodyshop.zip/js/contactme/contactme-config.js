/**
 *
 * ContactMe
 * https://www.21tools.it
 *
 */

"use strict";

// Language options
var cm_lang_path = 'contactme/lang/en.json';			// Choose the language of the error messages
var cm_datepicker_lang = 'en';							// Choose the language of the date picker plugin
var cm_dropdown_lang = 'en';							// Choose the language of the dropdown plugin
